# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.

 project description: Build navbar based on sections while changing the circle positions while scrolling.
 instructions:1- Click on the spiecfied section name to read more about it 
 2- Scroll the page  
 3- The section you're reading will be active in the menu

 technologies used: javascript and css.
 author's name: Ahella Mogharbel.



 

